export SOCFAMILY=g12b
