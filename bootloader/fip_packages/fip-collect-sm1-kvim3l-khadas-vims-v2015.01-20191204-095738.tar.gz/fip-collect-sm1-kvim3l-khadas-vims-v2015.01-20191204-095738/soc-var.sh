export SOCFAMILY=sm1
